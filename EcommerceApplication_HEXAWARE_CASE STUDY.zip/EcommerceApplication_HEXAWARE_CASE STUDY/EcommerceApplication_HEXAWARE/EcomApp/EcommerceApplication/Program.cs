﻿using EcommerceApplication.Main;
using System;

namespace EcommerceApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // Start the Ecom Application
            EcomApplication.Start();
        }
    }
}

