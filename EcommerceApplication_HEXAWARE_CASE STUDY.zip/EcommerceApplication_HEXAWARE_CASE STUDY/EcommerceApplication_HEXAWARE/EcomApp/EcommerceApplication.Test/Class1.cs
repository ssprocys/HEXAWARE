﻿using NUnit.Framework;
using EcommerceApplication.Model;
using EcommerceApplication.Repository;
namespace EcommerceApplication.Test
{
    public class Class1
    {
        [Test]
        public void CreateProductTest()
        {
            var product = new Product
            {
                Name = "Test Product",
                Price = 99.99m,
                Description = "This is a test product.",
                StockQuantity = 10
            };
            var productService = new ProductRepository(); // Assuming this class contains the CreateProduct method

            // Act
            bool result = productService.CreateProduct(product);

            // Assert
            Assert.That(result, Is.EqualTo(true));
        }

        [Test]
        public void AddToCartTest()
        {
            var customerId = 1;
            var productId = 1;
            var quantity = 2;

            var cartRepository = new CartRepository();
            bool result = cartRepository.AddToCart(customerId, productId, quantity);

            // Assert
            Assert.That(result, Is.EqualTo(true));
        }

        [Test]
        public void PlaceOrderTest()
        {
            int customerId = 1; // Use a valid customer ID from your database
            string shippingAddress = "123 Test Street";
            var cartItems = new List<Cart>
     {
         new Cart { ProductId = 1, Quantity = 2 }, // Ensure these product IDs and quantities are valid
         new Cart { ProductId = 2, Quantity = 1 }
     };
            var orderRepository = new OrderRepository();
            bool result = orderRepository.PlaceOrder(customerId, cartItems, shippingAddress);

            // Assert
            Assert.That(result, Is.EqualTo(true));
        }
    }
}
