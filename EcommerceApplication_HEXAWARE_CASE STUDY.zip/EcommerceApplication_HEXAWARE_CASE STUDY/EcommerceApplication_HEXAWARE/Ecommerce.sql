-- Create Database
CREATE DATABASE Ecommerce;

-- Use the database
USE Ecommerce;

-- Customers Table
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(255) UNIQUE NOT NULL,
    password NVARCHAR(100) NOT NULL
);

-- Products Table
CREATE TABLE Products (
    product_id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description NVARCHAR(255),
    stockQuantity INT NOT NULL
);

-- Cart Table
CREATE TABLE Cart (
    cart_id INT PRIMARY KEY IDENTITY(1,1),
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id) ON DELETE CASCADE
);

-- Orders Table
CREATE TABLE Orders (
    order_id INT PRIMARY KEY IDENTITY(1,1),
    customer_id INT NOT NULL,
    order_date DATE NOT NULL DEFAULT GETDATE(),
    total_price DECIMAL(18, 2) NOT NULL,
    shipping_address NVARCHAR(255) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE
);

-- Order Items Table
CREATE TABLE OrderItems (
    order_item_id INT PRIMARY KEY IDENTITY(1,1),
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id) ON DELETE CASCADE
);

-- Insert Sample Customers
INSERT INTO Customers (name, email, password)
VALUES 
('Krishna', 'krish@example.com', 'password123'),
('Shiv', 'Shiv@example.com', 'password456'),
('Mavad', 'Mavad@example.com', 'password789');

-- Insert Sample Products
INSERT INTO Products (name, price, description, stockQuantity)
VALUES
('Smartphone', 699.99, 'Latest model smartphone with high performance.', 50),
('Laptop', 999.99, 'High-end gaming laptop with powerful specs.', 20),
('Wireless Headphones', 199.99, 'Noise-cancelling over-ear headphones.', 100),
('Smart Watch', 299.99, 'Feature-packed smartwatch with long battery life.', 30);

-- Insert Sample Carts
-- Assuming Customer 1 adds two products to the cart
INSERT INTO Cart (customer_id, product_id, quantity)
VALUES
(1, 1, 2), -- Customer 1 adds 2 Smartphones
(1, 3, 1); -- Customer 1 adds 1 Wireless Headphone

-- Insert Sample Orders
-- Assuming Customer 2 places an order
INSERT INTO Orders (customer_id, total_price, shipping_address)
VALUES
(2, 1299.98, '123 abc Street, Karupur, Chennai, TamilNadu');

-- Insert Sample Order Items
-- Assuming Customer 2 orders 1 Laptop and 1 Smartphone
INSERT INTO OrderItems (order_id, product_id, quantity)
VALUES
(1, 2, 1), -- Order ID 1, 1 Laptop
(1, 1, 1); -- Order ID 1, 1 Smartphone

select * from customers
select * from Products
select * from Cart
SELECT price FROM Products WHERE product_id = 1;

SELECT c.product_id, p.name AS product_name, c.quantity, p.price
FROM Cart c
JOIN Products p ON c.product_id = p.product_id
WHERE c.customer_id = 1;

