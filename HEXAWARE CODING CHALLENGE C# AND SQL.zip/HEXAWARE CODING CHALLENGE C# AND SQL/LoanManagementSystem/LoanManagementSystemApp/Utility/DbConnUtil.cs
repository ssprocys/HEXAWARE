﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//namespace LoanManagementSystemApp.Utility
//{
 


//    namespace BikeStoreAPPWithDatabase.Utility
//    {
//        internal static class DbConnUtil
//        {
//            private static IConfiguration _iconfiguration;

//            static DbConnUtil()
//            {
//                GetAppSettingsFile();
//            }


//            private static void GetAppSettingsFile()
//            {
//                var builder = new ConfigurationBuilder()
//                            .SetBasePath(Directory.GetCurrentDirectory())
//                            .AddJsonFile("appsettings.json");
//                _iconfiguration = builder.Build();
//            }

//            public static string GetConnectionString()
//            {
//                return _iconfiguration.GetConnectionString("LocalConnectionString");
//            }


//        }
//    }

//}
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace LoanManagementSystemApp.Utility
//{
//    internal static class DBConnUtil
//    {
//        private static IConfiguration _iconfiguration;

//        static DBConnUtil()
//        {
//            GetAppSettingsFile();
//        }

//        private static void GetAppSettingsFile()
//        {
//            var builder = new ConfigurationBuilder()
//                        .SetBasePath(Directory.GetCurrentDirectory())
//                        .AddJsonFile("appsettings.json");
//            _iconfiguration = builder.Build();
//        }

//        public static string GetConnectionString()
//        {
//            return _iconfiguration.GetConnectionString("LocalConnectionString");
//        }
//    }
//}
internal static class DBConnUtil
{
    private static IConfiguration _iconfiguration;

    static DBConnUtil()
    {
        GetAppSettingsFile();
    }

    private static void GetAppSettingsFile()
    {
        var builder = new ConfigurationBuilder()
                      .SetBasePath(AppContext.BaseDirectory) // Ensures correct base directory
                      .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true); // Reads the file
        _iconfiguration = builder.Build(); // Builds the configuration
    }

    public static string GetConnectionString()
    {
        if (_iconfiguration == null)
        {
            throw new InvalidOperationException("Configuration is not initialized.");
        }

        return _iconfiguration.GetConnectionString("LocalConnectionString");
    }
}

